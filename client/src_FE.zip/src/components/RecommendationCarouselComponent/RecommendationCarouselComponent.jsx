import React, { useEffect, useState } from "react";
import Slider from "react-slick";
import { getRecommendedProducts } from "../../services/RecommendationService";
import CardProduct from "../CardProduct/CardProduct"; // Component hiển thị sản phẩm
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import styles from "./RecommendationCarouselComponent.module.css";
import { useSelector } from "react-redux";

const RecommendationCarouselComponent = ({ userId }) => {
  //   console.log("usss", userId);

  //   const user = useSelector((state) => state.user);
  const [recommendedProducts, setRecommendedProducts] = useState([]);

  useEffect(() => {
    const fetchRecommendations = async () => {
      if (userId) {
        try {
          const products = await getRecommendedProducts(userId);
          console.log("Recommended products:", products);

          if (!Array.isArray(products)) {
            throw new Error("Dữ liệu trả về không phải mảng!");
          }

          setRecommendedProducts(products);
        } catch (error) {
          console.error("Lỗi khi lấy sản phẩm khuyến nghị:", error);
          if (error.response) {
            console.error("Response Data:", error.response.data);
            console.error("Response Status:", error.response.status);
          }
        }
      }
    };

    fetchRecommendations();
  }, [userId]);

  const settings = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true,
  };

  return (
    <div className="recommendation-container">
      <Slider {...settings}>
        {recommendedProducts.map((product) => (
          <CardProduct key={product._id} product={product} />
        ))}
      </Slider>
    </div>
  );
};

export default RecommendationCarouselComponent;
