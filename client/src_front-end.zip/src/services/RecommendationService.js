import axios from "axios";

export const getRecommendedProducts = async (userId) => {
  console.log(`Gọi API lấy sản phẩm khuyến nghị cho user: ${userId}`);
  try {
    const res = await axios.get(
      `${process.env.REACT_APP_API_URL_BACKEND}/recommendation/get-recommend/${userId}`,
      {
        headers: {
          "Content-Type": "application/json",
        },
      }
    );
    console.log("Kết quả API:", res.data);
    return res.data;
  } catch (error) {
    if (error.response) {
      throw {
        message: error.response.data?.message || "Đã xảy ra lỗi.",
      };
    } else {
      throw { status: 500, message: "Không thể kết nối đến máy chủ." };
    }
  }
};
